﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_iteration_2_try_2nd
{
    public class Add_Project : Projects
    {
        private int Input_name;
        private int Input_Description;
        private int Inputed_File;
        private int Inputed_phot;
        private int Inputed_visibility;
        private int Add_new_project;

        public Confirmation Confirmation
        {
            get => default;
            set
            {
            }
        }

        public void Add_to_list()
        {
            throw new System.NotImplementedException();
        }
    }
}