﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_iteration_2_try_2nd
{
    public class Edit_project : Projects
    {
        private int Edit_Project_propurties;

        public Confirmation Confirmation
        {
            get => default;
            set
            {
            }
        }
    }
}