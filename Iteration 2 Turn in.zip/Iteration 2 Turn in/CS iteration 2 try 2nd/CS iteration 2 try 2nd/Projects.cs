﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_iteration_2_try_2nd
{
    public class Projects : Project_list
    {
        public int Name
        {
            get => default;
            set
            {
            }
        }

        public int Visible
        {
            get => default;
            set
            {
            }
        }

        public int Description
        {
            get => default;
            set
            {
            }
        }

        public int Linked_file
        {
            get => default;
            set
            {
            }
        }

        public int Photo
        {
            get => default;
            set
            {
            }
        }

        public void Logged_in()
        {
            throw new System.NotImplementedException();
        }
    }
}