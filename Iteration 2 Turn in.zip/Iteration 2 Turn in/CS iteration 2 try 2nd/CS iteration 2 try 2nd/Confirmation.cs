﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_iteration_2_try_2nd
{
    public class Confirmation
    {
        public bool Confirmed
        {
            get => default;
            set
            {
            }
        }
    }
}