﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_iteration_2_try_2nd
{
    public class Login : Student
    {
        private int Check_username;
        private int Check_password;

        public void Grab_username()
        {
            throw new System.NotImplementedException();
        }

        public void Grab_password()
        {
            throw new System.NotImplementedException();
        }
    }
}